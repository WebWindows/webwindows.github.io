# ![](../../images/icons/solitaire-32x32.png) JavaScript Solitaire Game

A Windows Solitaire clone by [Radovan Janjic](https://github.com/rjanjic)

Try it [as part of 98](https://98.js.org/) or [standalone](https://98.js.org/programs/js-solitaire/)


![JavaScript Solitaire](screen-shot.png)

![JavaScript Solitaire Win](screen-shot-win.png)

The original repo: https://github.com/rjanjic/js-solitaire/

The original demo: http://radovanjanjic.com/js-solitaire/
