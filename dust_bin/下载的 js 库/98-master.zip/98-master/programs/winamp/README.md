
# ![](../../images/icons/winamp2-32x32.png) Winamp 2.9

[Webamp](https://github.com/captbaritone/webamp) by [Jordan Eldredge](https://jordaneldredge.com/)

Try it [on 98.js.org](https://98.js.org/) or [standalone at webamp.org](https://webamp.org/)


### TODO

* Keyboard shortcuts should only apply when Winamp is focused

* Interop with Sound Recorder should be fun! ;)

* Touchscreen window movement

* Include more skins? Having a catalog would be nice...
