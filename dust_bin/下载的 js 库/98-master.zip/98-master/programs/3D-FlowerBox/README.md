# ![](../../images/icons/pipes-32x32.png) 3D-FlowerBox

Faithful WebGL remake of the Classic Windows 95 Screensaver, by [Kevin Shannon](https://github.com/kevin-shannon)

Try it [as part of 98](https://98.js.org/) or [standalone](https://98.js.org/programs/3D-FlowerBox/)

![FlowerBox](img/FlowerBox.PNG)

Original repository: https://github.com/kevin-shannon/3D-FlowerBox
